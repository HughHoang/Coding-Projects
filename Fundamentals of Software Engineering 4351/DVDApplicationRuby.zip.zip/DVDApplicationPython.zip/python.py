#Hugh Hoang 1833106 Spring 2021
class DVD:
    def __init__(self, name, age,intitle, incategory, inruntime, inyor, inprice):
        self.title = intitle
        self.category = incategory
        self.runtime = inruntime
        self.yor = inyor
        self.price = inprice
def restoreCatalog(currentcatalog):
    file1 = open("Catalog.txt", "w")  # write mode
    for x in currentcatalog:
        file1.write("x \n")
    file1.close()

def addDVD():
    file1 = open("Catalog.txt", "a")  # append mode
    title = input("New DVD's title name?")
    category = input("ew DVD's category name?")
    runtime = input("New DVD's running time?")
    yor = input("New DVD's year of release?")
    price = input("New DVD's price?")
    text = title + "," + category + "," + runtime + "," + yor + "," + price
    file1.write(text+ "\n")

def displaycategory(categoryname):
    file1 = open("myfile.txt", "r")
    lines = file1.readlines()
    for line in lines:
        startindexcat=GetNthIndex(line, ',', 1)
        endindexcat=GetNthIndex(line, ',', 2)
        category = line[startindexcat + 1:endindexcat]
        if category==categoryname:
            file1.write(line+ "\n")
                
def savecatalog(category):
        file1 = open("myfile.txt", "r")
        lines = file1.readlines()
        dvdnumber=0
        for line in lines:
            indextitle = GetNthIndex(line, ',', 1)
            indexcategory = GetNthIndex(line, ',', 2)
            indexruntime = GetNthIndex(line, ',', 3)
            indexyor = GetNthIndex(line, ',', 4)
            title = line[0:indextitle] 
            category = line[indextitle + 1:indexcategory - 1]
            runtime = line[indexcategory + 1:indexruntime - 1]
            yor = line[indexruntime + 1:indexyor - 1]
            price = line[indexyor + 1:line.length]
            currDVD = DVD(title,category,runtime,yor,price)
            currentcatalog[dvdnumber] = currDVD
            dvdnumber+= 1
        
def GetNthIndex(x, y, n):
        start = x.find(y)
        while start >= 0 and n > 1:
            start = x.find(y, start+len(y))
            n -= 1
        return start

currentcatalog=[]
print("1.restore Catalog")
print("2.add DVD")
print("3.display DVDs by category")
print("4.save Catalog")
option = input()
if option == "1":
    restoreCatalog(currentcatalog)
elif option == "2":
    addDVD()
elif(option == "3"):
    categoryname = input("Display by what category?")
    displaycategory(categoryname)
elif(option == "4"):
    currentcatalog= savecatalog(currentcatalog)