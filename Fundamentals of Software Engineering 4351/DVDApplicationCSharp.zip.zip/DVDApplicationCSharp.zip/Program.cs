﻿using System;
using System.IO;
//Hugh Hoang 1833106 Spring 2021
class DVD
{
    string title, category, runtime, yor, price;
    // Constructor that takes no arguments:
    public DVD()
    {

    }

    // Constructor that takes one argument:
    public DVD(string intitle, string incategory, string inruntime, string inyor, string inprice)
    {
        title = intitle;
        category = incategory;
        runtime = inruntime;
        yor = inyor;
        price = inprice;
    }
}
class DVDCatalog
{
    public static void Main()
    {
        DVD[] currentcatalog = new DVD[100];
        showSelection();
        string option = Console.ReadLine();
        if (option == "1")
        {
            using (StreamWriter w = File.AppendText("Catalog.txt"))
            {
                restoreCatalog(currentcatalog,w);
            }
        }
        else if (option == "2")
        {
            
            using (StreamWriter w = File.AppendText("Catalog.txt"))
            {
                Console.WriteLine("New DVD's title name?");
                string title = Console.ReadLine();
                Console.WriteLine("New DVD's category name?");
                string category = Console.ReadLine();
                Console.WriteLine("New DVD's running time?");
                string runtime = Console.ReadLine();
                Console.WriteLine("New DVD's year of release?");
                string yor = Console.ReadLine();
                Console.WriteLine("New DVD's price?");
                string price = Console.ReadLine();
                string text = title + "," + category + "," + runtime + "," + yor + "," + price;

                addDVD(text,w);
            }
        }
        else if (option == "3")
        {
            using (StreamReader r = File.OpenText("Catalog.txt"))
            {
                Console.WriteLine("Display by what category?");
                string categoryname = Console.ReadLine();
                displayCategory(categoryname, r);
            }
        }
        else if (option == "4")
        {
            using (StreamReader r = File.OpenText("Catalog.txt"))
            {
                currentcatalog= saveCatalog(currentcatalog, r);
            }
        }
        else
        {
            Console.WriteLine($"Not valid option");
        }


    }
    public static void showSelection()
    {
        Console.WriteLine("Welcome to DVD Catalog. Pick an option");
        Console.WriteLine("1.restore Catalog");
        Console.WriteLine("2.add DVD");
        Console.WriteLine("3.display DVDs by category");
        Console.WriteLine("4.save Catalog");
    }
    public static void restoreCatalog(DVD[] currentcatalog,TextWriter w)
    {
        //clears
        System.IO.File.WriteAllText("Catalog.txt", string.Empty);
        for(int i = 0; i < currentcatalog.Length; i++)
        {
            w.WriteLine(currentcatalog[i]);
        }
    }
    public static void addDVD(string text, TextWriter w)
    {
       w.WriteLine(text);
    }
    public static void displayCategory(string categoryname, TextReader w)
    {
        string[] lines = File.ReadAllLines("Catalog.txt");

        foreach (string line in lines)
        {
            int pFrom = line.IndexOf(",") + ",".Length;
            int pTo = line.IndexOf(',', line.IndexOf(',') + 1);
            String result = line.Substring(pFrom, pTo - pFrom);
            if (result==categoryname)
            {
                Console.WriteLine(line);
            }
        }
    }
    public static DVD[] saveCatalog(DVD[] currentcatalog, TextReader w)
    {
        string[] lines = File.ReadAllLines("Catalog.txt");
        int dvdnumber = 0;


        foreach (string line in lines)
        {
            int indextitle = GetNthIndex(line, ',', 1);
            int indexcategory = GetNthIndex(line, ',', 2);
            int indexruntime = GetNthIndex(line, ',', 3);
            int indexyor = GetNthIndex(line, ',', 4);
            String title = line.Substring(0, indextitle);
            String category = line.Substring(indextitle + 1, indexcategory - indextitle - 1);
            String runtime = line.Substring(indexcategory + 1, indexruntime - indexcategory - 1);
            String yor = line.Substring(indexruntime + 1, indexyor - indexruntime - 1);
            String price = line.Substring(indexyor + 1, line.Length - indexyor - 1);
            DVD currDVD = new DVD(title,category,runtime,yor,price);
            currentcatalog[dvdnumber] = currDVD;
            dvdnumber+= 1;
        }
        return currentcatalog;
    }
    public static int GetNthIndex(string s, char t, int n)
    {
        int count = 0;
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] == t)
            {
                count++;
                if (count == n)
                {
                    return i;
                }
            }
        }
        return -1;
    }
}

