
<?php
//Hugh Hoang 1833106 Spring 2021
class DVD {
    public $title;
    public $category;
    public $runtime;
    public $yor;
    public $price;
    function set_title($title) {
        $this->title = $title;
      }
      function set_category($category) {
        $this->category = $category;
      }
      function set_runtime($runtime) {
        $this->runtime = $runtime;
      }
      function set_yor($yor) {
        $this->yor = $yor;
      }
      function set_price($price) {
        $this->price = $price;
      }
}

$foo = new DVD;
?>

<?php
//Hugh Hoang 1833106 Spring 2021
class DVDCatalog{
    public $dvds = array();
    function showSelection()
    {
        print("Welcome to DVD Catalog. Pick an option");
        print("1.restore Catalog");
        print("2.add DVD");
        print("3.display DVDs by category");
        print("4.save Catalog");
    }

function restoreCatalog($currentcatalog)
    {
        $myfile = fopen("Catalog.txt", "w");
        for($i = 0; $i <= currentcatalog.Length; $i++) {
            fwrite($myfile, $currentcatalog[i]);
        }
    }
    function addDVD($text)
    {
        $myfile = fopen("Catalog.txt", "w");
        $title = readline("New DVD's title name?");
        $category = readline("New DVD's category name?");
        $runtime = readline("New DVD's running time?");
        $yor = readline("New DVD's year of release?");
        $price = readline("New DVD's price?");
        $text = title + "," + category + "," + runtime + "," + yor + "," + price;

        fwrite($myfile, $currentcatalog[i]);
    }
    function displayCategory($categoryname)
    {
        $myfile = fopen("Catalog.txt", "w");
        echo fread($myfile,filesize("Catalog.txt.txt"));
        for($i = 0; $i <= currentcatalog.Length; $i++) {
            {
                if(currentcatalog[i]==categoryname){
                    print(myfile);
                }
            }
        }
    }
    function saveCatalog($currentcatalog)
    {
        $myfile = fopen("Catalog.txt", "w");
        $dvdnumber = 0;

        for($i = 0; $i <= currentcatalog.Length; $i++) {
        {
            $indextitle = strposnth(line, ',', 1);
            $indexcategory = strposnth(line, ',', 2);
            $indexruntime = strposnth(line, ',', 3);
            $indexyor = strposnth(line, ',', 4);
            $title = line.Substring(0, indextitle);
            $category = line.Substring(indextitle + 1, indexcategory - indextitle - 1);
            $runtime = line.Substring(indexcategory + 1, indexruntime - indexcategory - 1);
            $yor = line.Substring(indexruntime + 1, indexyor - indexruntime - 1);
            $price = line.Substring(indexyor + 1, line.Length - indexyor - 1);
            currDVD = new DVD(title,category,runtime,yor,price);
            currentcatalog[dvdnumber] = currDVD;
            dvdnumber+= 1;
        }
        return currentcatalog;
    }
    

    function strposnth($haystack, $needle, $nth=1, $insenstive=0)
    {
       if ($insenstive) {
           $haystack=strtolower($haystack);
           $needle=strtolower($needle);
       $count=substr_count($haystack,$needle);
      if ($count<1 || $nth > $count) return false;
    
      for($i=0,$pos=0,$len=0;$i<$nth;$i++)
       {   
           $pos=strpos($haystack,$needle,$pos+$len);
    
           if ($i==0) $len=strlen($needle);
         }
      
       return $pos;
    }
}
?>
