"""
Program to predict the sentiment of input text as either positive, negative, or neutral.
"""


def read_sentences(filename):
    """
    Read the input text file line by line and
    return the data as a list of tuples.
    Output format example: [('1', 'hello , how are you?'), ('2', 'have a great day !'), ...]
    """
    # Enter your code here.


def read_sentiment_words(filename):
    """
    Read the input text file line by line and 
    return the dictionary of words with their value set to zero.
    Output format example: {'orange':0, 'banana':0,...}.
    This function will be used once for the positive word file and once for the negative word file.
    """
    # Enter your code here.


positive_word_dict = # Enter code here. Use above function to read positive sentiment words from file
negative_word_dict = # Enter code here. Use above function to read negative sentiment words from file
# Purpose of above is to ensure that the rest of your program has access to the positive and negative word dictionaries
# So you don't have to pass them as arguments to other functions.


def predict_sentiment(review_text):
    """
    Find the sentiment of the review text, based on the sentiment of each word in the text.
    Return "positive", "negative", or "neutral" depending on the total sentiment word count value.
    Note that this function will receive a block of review text as a string, not the entire file of reviews.
    """
    # Enter your code here.


def write_sentiments(filename, sentence_sentiment_lst):
    """
	Write review text sentiment values to file given by filename.
	I.e. If this function receives "sentimentOutput.txt" as an argument, it should write to sentimentOutput.txt.
	The sentence index and the sentiment value must be separated by a comma. Make calls to function(s) defined above to
	generate the result.
	Example Input: sentence_sentiment_lst = [('1', 'hello , how are you?'), ('2', 'have a great day !'), ...]
	Example Output: 1, positive
	                2, negative
	                3, neutral
	"""
    # Enter your code here.


def most_frequent_sentiment_word(sentiment_word_dict):
    """
    Find the word with the highest frequency value from the dictionary and
    return the word and its frequency as a dictionary. Note that this function will
    be used once for positive words and once for negative words.
    Example output: {'goodword':50}
    """
    # Enter your code here.


def  write_sentiment_words(filename,  top_word_frequency_dict):
    """
	Write the word and frequency value for the most frequent sentiment word to the file given by filename,
	separated by a comma. This function will have to be called once for positive words and once for negative words.
	I.e. If this function receives "topwords.txt" as an argument, it should write to topwords.txt.
    Example Output: goodword, 50
                    badword, 45
    Note that the positive word was listed first, then negative word. You should ensure your file has its results
    in this same order after main() is executed.
	"""
    # Enter your code here.


def main():
    """
    After you have defined the above functions, write a solution in main that will produce sentiments.txt and
    top_sentiment_words.txt as described in the assignment. Note that if your main function creates those files
    but your other functions do not return the correct results, you will only get credit for main.
    EACH of your functions will have to pass individual test cases, so read the instructions carefully.
    """
    # Enter your code here.





""" Do not alter below"""
if __name__ == '__main__':
	main()