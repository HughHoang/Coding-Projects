import cv2
import numpy as np 

im=cv2.imread('uh.png')											# Reads image from current folder
height,width,channels=im.shape									# Gets the shape of the image
print('Original Image Dimensions:',im.shape)					
maxpooled=np.empty(shape=(height//2,width//2,3))				# Initializing an empty array with half the dimensions of the input image

'''Write your code here'''

print('Max-pooled Image Dimensions:',maxpooled.shape)			# Prints dimensions of the maxpooled image
cv2.imwrite('maxpooled.png',maxpooled)							# Stores image
