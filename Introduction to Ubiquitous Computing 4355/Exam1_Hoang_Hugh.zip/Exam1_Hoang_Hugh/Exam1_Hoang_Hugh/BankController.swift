//
//  BankController.swift
//  Exam1_Hoang_Hugh
//
//  Created by student on 9/22/22.
//

import UIKit

class BankController: UIViewController {

    @IBOutlet weak var Spins: UILabel!
    @IBOutlet weak var Won: UILabel!
    @IBOutlet weak var Credit: UILabel!
    @IBOutlet weak var moneyInput: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    var credit = 100
    var won=0
    var spins=0
    func updateScore() {
        Spins.text="Spins:                                         \(spins)"
        Won.text="Won:                                           \(won)"
        Credit.text="Credit:                                \(credit)"
    }
    override func viewDidAppear(_ animated: Bool) {
        self.updateScore()
    }
    @IBAction func addCredit(_ sender: Any) {
        if moneyInput.text?.count == 0 {
            let actionSheetAlert = UIAlertController(title: "Please enter valid number", message: "Please add more credit ast the bank tab.", preferredStyle: .actionSheet)
        }
        else {
            if let test = moneyInput.text {
                let moneynumber = Int(moneyInput.text ?? "") ?? 0
                credit=credit + moneynumber
                self.updateScore()
                updateFirst()
            }
            else {
                let actionSheetAlert = UIAlertController(title: "Please enter valid number", message: "Please add more credit at the bank tab.", preferredStyle: .actionSheet)
            }
        }
    }
    func updateFirst() {
        let firstTab = self.tabBarController?.children[0] as! GameController
        firstTab.won = won
        firstTab.spins = spins
        firstTab.credit = credit
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
