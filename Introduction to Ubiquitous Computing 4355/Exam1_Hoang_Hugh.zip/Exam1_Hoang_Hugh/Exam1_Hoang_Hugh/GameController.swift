//
//  GameController.swift
//  Exam1_Hoang_Hugh
//
//  Created by student on 9/22/22.
//

import UIKit

class GameController: UIViewController {

    var credit = 100
    var bet=1
    var won=0
    var spins=0
    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var image2: UIImageView!
    @IBOutlet weak var image3: UIImageView!
    @IBOutlet weak var CreditBet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func updateSecond() {
        let secondTab = self.tabBarController?.children[1] as! BankController
        secondTab.won = won
        secondTab.spins = spins
        secondTab.credit = credit
    }
    
    
    
    let slots = [UIImage(named:"1"),
                     UIImage(named:"2"),
                     UIImage(named:"3"),
                     UIImage(named:"4"),
                     UIImage(named:"5"),
                     UIImage(named:"6"),
                     UIImage(named:"7"),
                     UIImage(named:"8"),
                     UIImage(named:"9"),]
    
    func generateRandomNumber(from: Int, to: Int) -> Int {
        return Int.random(in: from..<to)
    }
    
    @IBAction func spin(_ sender: Any) {
        if(bet>=credit){
            let actionSheetAlert = UIAlertController(title: "Not enough credit!", message: "Please add more credit at the bank tab.", preferredStyle: .actionSheet)
            bet=1
        }
        else{
            if(spins%4==0 && spins>0){
                let randslot1 = Int.random(in: 0..<8)
                image1.image = slots[randslot1]
                image2.image = slots[randslot1]
                image3.image = slots[randslot1]
                credit = credit + 10*bet;
                    won = won + 10*bet;
                    bet = 1;
                    spins = spins + 1
            }
            else{
                let randslot1 = Int.random(in: 0..<8)
                let randslot2 = Int.random(in: 0..<8)
                let randslot3 = Int.random(in: 0..<8)
                image1.image = slots[randslot1]
                image2.image = slots[randslot2]
                image3.image = slots[randslot3]
                if(randslot1==randslot2 && randslot2==randslot3){
                    credit = credit + 10*bet;
                    won = won + 10*bet;
                    bet = 1;
                    spins = spins + 1
                }
                else{
                    credit = credit - bet;
                    bet = 1;
                    spins = spins + 1
                }
            }
        }
        CreditBet.text = "Credit:\(credit) Bet:\(bet)"
    }
    @IBAction func bet(_ sender: Any) {
        bet=bet*2
        if(bet>=1000){
            bet=1
        }
        CreditBet.text = "Credit:\(credit) Bet:\(bet)"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
