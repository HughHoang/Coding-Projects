//
//  ViewController.swift
//  Exercise_Week2
//
//  Created by Shaila Zaman on 9/1/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var helperimage: UIImageView!
    @IBOutlet weak var header: UILabel!
    @IBOutlet weak var mem1: UILabel!
    @IBOutlet weak var mem2: UILabel!
    @IBOutlet weak var mem3: UILabel!
    @IBOutlet weak var mem4: UILabel!
    @IBOutlet weak var mem5: UILabel!
    @IBOutlet weak var mem6: UILabel!
    let UIAlertControl=["  configure alerts and action sheets", "  intended to be used as-is", "  does not support subclassing", "  inherits from UIViewController", "  support text fields to the alert interface", "  maintains a refence to each text field"]
    
    let UIKit = ["  provides required iOS infrastructure", "  window and view architecture", "  event handling for multi-touch and etc", "  manages interaction with system", "  a lot of features incl. resource mgnmnt", "  classes only from main thread"]
    let ViewController = ["  defines the behavior for common VCs", "  updates the content of the view", "  responding to user interactions", "  resizing views and layout mgmnt", "  coordinating with other objects", "  VC are UIResponder objects"]
    let helperimages: [UIImage] = [#imageLiteral(resourceName: "3"), #imageLiteral(resourceName: "2"), #imageLiteral(resourceName: "1")]
    var topic = 0
    
    func getRandomTopic() -> Int {
        return(Int.random(in: 1 ... 3))
    }
    func currentTopic() {
        if header.text?.count != 0 {
            topic = (topic)%3
            if(topic==0){
                header.text="UIAlertControl"
                mem1.text = UIAlertControl[0];
                mem2.text = UIAlertControl[1];
                mem3.text = UIAlertControl[2];
                mem4.text = UIAlertControl[3];
                mem5.text = UIAlertControl[4];
                mem6.text = UIAlertControl[5];
                helperimage.image = helperimages[0]
            }
            else if(topic==1){
                header.text="UIKit"
                mem1.text = UIKit[0];
                mem2.text = UIKit[1];
                mem3.text = UIKit[2];
                mem4.text = UIKit[3];
                mem5.text = UIKit[4];
                mem6.text = UIKit[5];
                helperimage.image = helperimages[1]
            }
            else{
                header.text="ViewController"
                mem1.text = ViewController[0];
                mem2.text = ViewController[1];
                mem3.text = ViewController[2];
                mem4.text = ViewController[3];
                mem5.text = ViewController[4];
                mem6.text = ViewController[5];
                helperimage.image = helperimages[2]
            }
        }    }
    @IBAction func NextTopic(_ sender: Any) {
        if header.text?.count != 0 {
            topic = (topic+1)%3
            if(topic==0){
                header.text="UIAlertControl"
                mem1.text = UIAlertControl[0];
                mem2.text = UIAlertControl[1];
                mem3.text = UIAlertControl[2];
                mem4.text = UIAlertControl[3];
                mem5.text = UIAlertControl[4];
                mem6.text = UIAlertControl[5];
                helperimage.image = helperimages[0]
            }
            else if(topic==1){
                header.text="UIKit"
                mem1.text = UIKit[0];
                mem2.text = UIKit[1];
                mem3.text = UIKit[2];
                mem4.text = UIKit[3];
                mem5.text = UIKit[4];
                mem6.text = UIKit[5];
                helperimage.image = helperimages[1]
            }
            else{
                header.text="ViewController"
                mem1.text = ViewController[0];
                mem2.text = ViewController[1];
                mem3.text = ViewController[2];
                mem4.text = ViewController[3];
                mem5.text = ViewController[4];
                mem6.text = ViewController[5];
                helperimage.image = helperimages[2]
            }
        }    }
    @IBAction func RandomTopic(_ sender: Any) {
        topic=(Int.random(in: 1 ... 3))
        if header.text?.count != 0 {
            topic = (topic+1)%3
            if(topic==0){
                header.text="UIAlertControl"
                mem1.text = UIAlertControl[0];
                mem2.text = UIAlertControl[1];
                mem3.text = UIAlertControl[2];
                mem4.text = UIAlertControl[3];
                mem5.text = UIAlertControl[4];
                mem6.text = UIAlertControl[5];
                helperimage.image = helperimages[0]
            }
            else if(topic==1){
                header.text="UIKit"
                mem1.text = UIKit[0];
                mem2.text = UIKit[1];
                mem3.text = UIKit[2];
                mem4.text = UIKit[3];
                mem5.text = UIKit[4];
                mem6.text = UIKit[5];
                helperimage.image = helperimages[1]
            }
            else{
                header.text="ViewController"
                mem1.text = ViewController[0];
                mem2.text = ViewController[1];
                mem3.text = ViewController[2];
                mem4.text = ViewController[3];
                mem5.text = ViewController[4];
                mem6.text = ViewController[5];
                helperimage.image = helperimages[2]
            }
        }  
    }
    
    @IBOutlet weak var selectalert: UICommand!
    @IBOutlet weak var selectkit: UICommand!
    let selecttopic=""
    let days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    let topics=["UIAlertControl","UIKit","ViewController"]
    
    @IBAction func button(_ sender: Any) {
        let actionSheetAlert = UIAlertController(title: "Pick a Day", message: "", preferredStyle: .actionSheet)
        for select in topics {
            actionSheetAlert.addAction(UIAlertAction(title: select, style: .default, handler: { _ in
            if(select=="UIAlertControl"){
                self.topic = 0
            }
            else if(select=="UIKit"){
                self.topic = 1
            }
            else if(select=="ViewController"){
                self.topic = 2
            }
            self.currentTopic()
        }))

        }
        actionSheetAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
            self.dismiss(animated: true, completion: nil)
        }))
        self.present(actionSheetAlert, animated: true, completion: nil)    }
}

