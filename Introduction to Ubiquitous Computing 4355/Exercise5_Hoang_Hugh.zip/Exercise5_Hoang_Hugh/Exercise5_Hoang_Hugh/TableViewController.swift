//
//  TableViewController.swift
//  Exercise5_Hoang_Hugh
//
//  Created by student on 10/6/22.
//

import UIKit

struct Zones: Codable {
    init() {
        
        map = URL(string: "http://www.google.com")!
        logo = URL(string: "http://www.google.com")!
        info = URL(string: "http://www.google.com")!
        name = ""
        close_to = ""
        about = ""
        lots = ""
        free = 0
    }
    
    let map: URL
    let logo: URL
    let info: URL
    let name: String
    let close_to: String
    let about: String
    let lots: String
    let free: Int
}

class TableViewController: UITableViewController{
    
    //you can copy both the table views verbatim, they're from the tutorial they gave us
    var zones = [Zones]()
    var currentZone = Zones()
    var curColor = UIColor.systemRed
    let colors = [
        UIColor(red: 160/255, green: 145/255, blue: 122/255, alpha: 1.0),
        UIColor(red: 15/255, green: 149/255, blue: 137/255, alpha: 1.0),
        UIColor(red: 50/255, green: 114/255, blue: 174/255, alpha: 1.0),
        UIColor(red: 157/255, green: 67/255, blue: 112/255, alpha: 1.0),
        UIColor(red: 148/255, green: 77/255, blue: 144/255, alpha: 1.0),
        UIColor(red: 192/255, green: 62/255, blue: 83/255, alpha: 1.0),
        UIColor(red: 201/255, green: 0, blue: 108/255, alpha: 1.0),
        UIColor(red: 111/255, green: 143/255, blue: 40/255, alpha: 1.0)
    ]
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return(zones.count)
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 92
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let name = cell.viewWithTag(1) as! UILabel
        let free = cell.viewWithTag(2) as! UILabel

        name.text = zones[indexPath.row].name
        name.textColor = colors[indexPath.row]
        free.text = "Free: \(String(zones[indexPath.row].free))"
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        currentZone = zones[indexPath.row]
        curColor = colors[indexPath.row]
        self.performSegue(withIdentifier: "seg_details", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "seg_details" {
            let detailed_view = segue.destination as! ZoneViewController
            detailed_view.zone = currentZone
            detailed_view.color = curColor
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let url = URL(string: "https://cpl.uh.edu/courses/ubicomp/fall2022/webservice/parking/parkinglots.json")
        
        if url != nil {
            getData(url: url!)
        }
    }
    
    func getData(url: URL) {

        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in

            if let data = data {
                do {
                    // Convert the data to JSON
                    let jsonDecoder = JSONDecoder()
                    let qq = try jsonDecoder.decode(Array<Zones>.self, from: data)
                    self.zones = qq
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                } catch {
                    print("Error trying to decode JSON object")
                }

            } else if let error = error {
                print(error.localizedDescription)
            }
        }

        task.resume()
    }


}

