//
//  ViewController.swift
//  Exercise5_Hoang_Hugh
//
//  Created by user226509 on 10/10/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

