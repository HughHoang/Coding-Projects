//
//  ZoneViewController.swift
//  Exercise5_Hoang_Hugh
//
//  Created by student on 10/10/22.
//

import UIKit

class ZoneViewController: UIViewController {
    
    var zone = Zones()
    var color = UIColor.systemRed
    
    @IBOutlet weak var zoneLbl: UILabel!
    @IBOutlet weak var lotsLbl: UILabel!
    @IBOutlet weak var aboutLbl: UITextView!
    @IBOutlet weak var map: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        zoneLbl.text = zone.name
        zoneLbl.textColor = color
        lotsLbl.text = "Lots: \(zone.lots)"
        aboutLbl.text = zone.about
        
        URLSession.shared.dataTask(with: zone.map, completionHandler: { (data, response, error) in
            if error != nil {
                print(error!)
                return
            }
            DispatchQueue.main.async {
                self.map.image = UIImage(data: data!)
            }
        }).resume()
    }


}


