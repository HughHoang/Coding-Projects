//
//  TextAnalyzerViewController.swift
//  Exercise8_Hoang_Hugh
//
//  Created by student on 11/13/22.
//

import UIKit
import NaturalLanguage

class TextAnalyzerViewController: UIViewController {

    @IBOutlet weak var inputText: UITextField!
    @IBOutlet weak var nlpOutput: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    func showLemma() {
        let text = inputText.text!
        
        let tagger = NLTagger(tagSchemes: [.lemma])
        tagger.string = text
        
        var outputTxt = ""
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lemma) { tag, tokenRange in
            if let tag = tag {
                // print("\(text[tokenRange]): \(tag.rawValue.capitalized)")
                outputTxt = outputTxt + "\(text[tokenRange]): \(tag.rawValue.capitalized) \n"
            }
            return true
        }
        
        nlpOutput.text = outputTxt
    }
    
    

    @IBAction func applyNLP(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            nlpOutput.text = ""
        } else if sender.selectedSegmentIndex == 1 {
            showLemma()
        }
    }
    
}
