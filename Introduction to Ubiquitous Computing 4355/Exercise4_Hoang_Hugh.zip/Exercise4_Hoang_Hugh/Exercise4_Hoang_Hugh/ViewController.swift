//
//  ViewController.swift
//  Exercise4_Hoang_Hugh
//
//  Created by student on 9/15/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
