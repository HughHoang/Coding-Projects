//
//  ScoreViewController.swift
//  Exercise4_Hoang_Hugh
//
//  Created by student on 9/18/22.
//

import UIKit

class ScoreViewController: UIViewController {
    @IBOutlet weak var p1s1: UIImageView!
    @IBOutlet weak var p1s2: UIImageView!
    @IBOutlet weak var p1s3: UIImageView!
    @IBOutlet weak var p2s1: UIImageView!
    @IBOutlet weak var p2s2: UIImageView!
    @IBOutlet weak var p2s3: UIImageView!
    
    var score1 = 0
    var score2 = 0
    override func viewDidAppear(_ animated: Bool) {
        if(score1>=1){
            p1s1.alpha = 1
        }
        if(score1>=2){
            p1s2.alpha = 1
        }
        if(score1>=3){
            p1s3.alpha = 1
        }
        if(score2>=1){
            p2s1.alpha = 1
        }
        if(score2>=2){
            p2s2.alpha = 1
        }
        if(score2>=3){
            p2s3.alpha = 1
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
