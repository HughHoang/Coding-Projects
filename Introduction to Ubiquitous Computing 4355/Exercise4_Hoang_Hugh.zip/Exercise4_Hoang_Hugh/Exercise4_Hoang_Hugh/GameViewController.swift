//
//  GameViewController.swift
//  Exercise4_Hoang_Hugh
//
//  Created by student on 9/18/22.
//

import UIKit

class GameViewController: UIViewController {
    
    @IBOutlet weak var dragon1: UIImageView!
    @IBOutlet weak var dragon2: UIImageView!
    
    @IBOutlet weak var gametext: UILabel!
    @IBOutlet weak var fightButton: UIButton!
    
    let helperimages: [UIImage] = [#imageLiteral(resourceName: "1_Balerion"), #imageLiteral(resourceName: "1_Meraxes"), #imageLiteral(resourceName: "1_Sheepstealer"), #imageLiteral(resourceName: "2_Meleys"), #imageLiteral(resourceName: "2_Quicksilver"), #imageLiteral(resourceName: "2_Silverwing"), #imageLiteral(resourceName: "3_Drogon"), #imageLiteral(resourceName: "3_Drogon"), #imageLiteral(resourceName: "3_Viserion")]
    
    var score1 = 0
    var score2 = 0
        
        
        override func viewDidDisappear(_ animated: Bool) {
            let statsTab = self.tabBarController?.children[1] as! ScoreViewController
            statsTab.score1 = score1
            statsTab.score2 = score2
        }
        
        func generateRandomNumber(from: Int, to: Int) -> Int {
            return Int.random(in: from..<to)
        }
        
      
    @IBAction func Restart(_ sender: Any) {
        score1=0
        score2=0
        self.dismiss(animated: true, completion:nil)
    }
    let dragons = ["Balerion","Merxaes","Sheepstealer","Meleys","Quicksilver","Silverwing","Drogon","StormCloud","Viserion"]
    @IBAction func fightButton(_ sender: Any) {
        gametext.numberOfLines = 0
        if(score1>=3 || score2>=3){
            if(score1>=3){
                gametext.text = "Player 1 won! (\(score1), - \(score2)) \n Restart the game."
            }
            if(score2>=3){
                gametext.text = "Player 2 won! (\(score1), - \(score2)) \n Restart the game."
            }
        }
        else{
            let randdragon1 = Int.random(in: 0..<8)
            var randdragon2 = Int.random(in: 0..<8)
            while(randdragon1==randdragon2){
                randdragon2 = Int.random(in: 0..<8)
            }
            
            dragon1.image = helperimages[randdragon1]
            dragon2.image = helperimages[randdragon2]
            
            if randdragon1 > randdragon2 {
                gametext.text = "\(dragons[randdragon1]) is stronger \n Player 1 wins the round!"
                score1 += 1
            } else{
                gametext.text = "\(dragons[randdragon2]) is stronger \n Player 2 wins the round!"
                score2 += 1
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
