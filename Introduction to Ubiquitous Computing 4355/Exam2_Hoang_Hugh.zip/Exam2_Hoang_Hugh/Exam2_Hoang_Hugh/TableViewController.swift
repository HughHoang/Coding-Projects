//
//  TableViewController.swift
//  Exam2_Hoang_Hugh
//
//  Created by student on 10/20/22.
//

import UIKit


struct Gas: Codable {
    init() {
        station = ""
        logo = URL(string: "http://www.google.com")!
        reg = 0
        mid = 0
        prem = 0
        dies = 0
        
        gas_latitude = 0
        gas_longitude = 0
    }
    
    let station: String
    let logo: URL
    let reg: Double
    let mid: Double
    let prem: Double
    let dies: Double
    let gas_latitude: Double
    let gas_longitude: Double
}

class TableViewController: UITableViewController {
    @IBOutlet weak var gasType: UILabel!
    var selectedType = 0
    var selectedGas = Gas()
    var listGas = [Gas]()
    var gasTypes = ["Regular","Midgrade","Premium","Diesel"]
    override func viewDidLoad() {
        super.viewDidLoad()
        downloadData(url: URL(string: "https://cpl.uh.edu/courses/ubicomp/fall2022/webservice/gas.json")!)
        gasType.text = "\(gasTypes[selectedType]) gas"
    }
    
    func downloadData(url: URL) {
        URLSession.shared.dataTask(with: url){(data,response,error) in
            if let downloadedData = data{
                do {
                    self.listGas = try JSONDecoder().decode(Array<Gas>.self, from: downloadedData)
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                } catch {
                    print("Error in JSON decoding!")
                }
            }
        }.resume()
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listGas.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let GasLbl = cell.viewWithTag(1) as! UILabel
        let priceLbl = cell.viewWithTag(2) as! UILabel
        GasLbl.text = listGas[indexPath.row].station
        let gradePrices = [listGas[indexPath.row].reg,listGas[indexPath.row].mid,listGas[indexPath.row].prem,
                           listGas[indexPath.row].dies]
        priceLbl.text = "$ \(gradePrices[selectedType])"

        return cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "table_to_details" {
            let GasViewPage = segue.destination as! ViewController
            GasViewPage.selectedGas = selectedGas
            GasViewPage.selectedType = selectedType
        }
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedGas = listGas[indexPath.row]
        performSegue(withIdentifier: "table_to_details", sender: self)
    }
    
}

