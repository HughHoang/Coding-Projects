//
//  ViewController.swift
//  Exam2_Hoang_Hugh
//
//  Created by student on 10/20/22.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    
    var selectedGas = Gas()
    var selectedType = 0
    
    @IBOutlet weak var GasName: UILabel!
    @IBOutlet weak var regPrice: UILabel!
    @IBOutlet weak var midPrice: UILabel!
    @IBOutlet weak var premPrice: UILabel!
    @IBOutlet weak var diesPrice: UILabel!
    
    @IBOutlet weak var GasGrade: UILabel!
    @IBOutlet weak var logo: UIImageView!
    
    @IBAction func regPressed(_ sender: Any) {
    }
    @IBAction func midPressed(_ sender: Any) {
    }
    @IBAction func premPressed(_ sender: Any) {
    }
    @IBAction func diesPressed(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        regPrice.text = "$ \(selectedGas.reg)"
        midPrice.text = "$ \(selectedGas.mid)"
        premPrice.text = "$ \(selectedGas.prem)"
        diesPrice.text = "$ \(selectedGas.dies)"
        GasName.text = selectedGas.station
        
        URLSession.shared.dataTask(with: selectedGas.logo, completionHandler: { (data, response, error) in
            if error != nil {
                print(error!)
                return
            }
            DispatchQueue.main.async {
                self.logo.image = UIImage(data: data!)
            }
        }).resume()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "details_to_table" {
            let tablePage = segue.destination as! TableViewController
            tablePage.selectedType = selectedType
        }
    }
}

