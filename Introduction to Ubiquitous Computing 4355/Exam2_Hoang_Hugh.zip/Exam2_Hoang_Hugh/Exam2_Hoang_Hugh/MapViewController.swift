//
//  MapViewController.swift
//  Exam2_Hoang_Hugh
//
//  Created by student on 10/20/22.
//

import UIKit
import MapKit

class MapViewController: UIViewController {
    @IBOutlet weak var map: MKMapView!
    var selectedGas = Gas()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        showMap()
    }
    
    func showMap() {
        
        let span = MKCoordinateSpan(latitudeDelta: 0.01,longitudeDelta: 0.01)
        let capitalLocation = CLLocationCoordinate2DMake(selectedGas.gas_latitude, selectedGas.gas_longitude)
        let region = MKCoordinateRegion(center: capitalLocation, span: span)
        map.setRegion(region, animated: true)
        self.map.showsUserLocation = true
        
        
        let loc = CLLocation(latitude: self.selectedGas.gas_latitude, longitude: self.selectedGas.gas_longitude)
        CLGeocoder().reverseGeocodeLocation(loc) { (placemark, error) in
            if error != nil {
                print("Error in Map Loading")
                return
            }

            if let place = placemark?[0] {
                let annotation = MKPointAnnotation()
                annotation.coordinate = capitalLocation
                annotation.title = "\(self.selectedGas.station)"

                annotation.subtitle = "\(place.locality!), \(place.administrativeArea!), \(place.isoCountryCode!)"
                
                DispatchQueue.main.async {
                    self.map.addAnnotation(annotation)
                }
            }
        }
    }


}

