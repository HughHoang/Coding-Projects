//
//  Exercise7watchApp.swift
//  Exercise7watch Watch App
//
//  Created by student on 11/7/22.
//

import SwiftUI

@main
struct Exercise7watch_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
